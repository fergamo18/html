<?php _e('Listing title:', 'W2DC'); ?> <?php echo $listing_title; ?>

<?php _e('Listing URL:', 'W2DC'); ?> <?php echo $listing_url; ?>

<?php _e('Name:', 'W2DC'); ?> <?php echo $name; ?>

<?php _e('Email:', 'W2DC'); ?> <?php echo $email; ?>

<?php _e('Message:', 'W2DC'); ?>


<?php echo $message; ?>