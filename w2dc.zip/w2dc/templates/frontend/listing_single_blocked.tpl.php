		<div class="w2dc-content w2dc-listing-single">
			<?php w2dc_renderMessages(); ?>
		</div>