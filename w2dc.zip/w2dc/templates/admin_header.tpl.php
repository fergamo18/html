<div class="wrap">
	<?php w2dc_renderMessages(); ?>
	