<div class="w2dc-rating">
	<div class="w2dc-rating-stars">
		<label class="w2dc-rating-icon w2dc-fa <?php echo $rating->render_star(5); ?>"></label>
		<label class="w2dc-rating-icon w2dc-fa <?php echo $rating->render_star(4); ?>"></label>
		<label class="w2dc-rating-icon w2dc-fa <?php echo $rating->render_star(3); ?>"></label>
		<label class="w2dc-rating-icon w2dc-fa <?php echo $rating->render_star(2); ?>"></label>
		<label class="w2dc-rating-icon w2dc-fa <?php echo $rating->render_star(1); ?>"></label>
	</div>
</div>