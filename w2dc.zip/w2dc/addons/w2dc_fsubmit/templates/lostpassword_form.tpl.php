<div class="w2dc-content">
	<?php w2dc_renderMessages(); ?>

	<h3><?php _e('Please enter your username or email address. You will receive a link to create a new password via email.', 'W2DC') ?></h3>

	<div class="w2dc-submit-section-adv">
		<?php w2dc_lostpassword_form(); ?>
	</div>
</div>